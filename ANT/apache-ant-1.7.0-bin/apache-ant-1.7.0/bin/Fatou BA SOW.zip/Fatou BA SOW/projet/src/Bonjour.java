/**
*peinda
*peinda
*peinda
*/
public class Bonjour{
/**
*peinda
*peinda
*peinda
*/
 public static void main(String[] args) {
 	System.out.println("ça marche......");
 }

}